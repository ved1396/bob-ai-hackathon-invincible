import { GridSystemState, GridZone, RiskLevel, VoltageVariation, SubstationStatus } from '../src/types';

// Machine Learning Grid Risk Predictor Formula (Simulates XGBoost / Random Forest trained on grid telemetry)
export function calculateMLFailurePrediction(
  load: number,
  temp: number,
  voltageVar: VoltageVariation,
  freq: number,
  thd: number,
  vibration: number
): {
  probability: number;
  riskLevel: RiskLevel;
  drivers: string[];
  actions: string[];
  substationStatus: SubstationStatus;
} {
  // Base weights derived from grid fault physics & ML feature importance
  let riskScore = 0;
  const drivers: string[] = [];
  const actions: string[] = [];

  // 1. Load Factor (0 - 100%): Nominal <75%, Stress 75-88%, Extreme >88%
  if (load > 90) {
    riskScore += 38;
    drivers.push(`Extreme Load Saturation (${load}%) exceeding thermal envelope`);
    actions.push(`Initiate immediate load shedding (${Math.round((load - 80) * 2.5)} MW) to auxiliary feeders`);
  } else if (load > 80) {
    riskScore += 24;
    drivers.push(`High Feeder Load (${load}%) near peak operational limit`);
    actions.push(`Reroute secondary power flow through neighboring tie-lines`);
  } else if (load > 70) {
    riskScore += 12;
  } else {
    riskScore += 4;
  }

  // 2. Transformer Core Temperature (°C): Normal <32°C, High 35-40°C, Critical >40°C
  if (temp >= 42) {
    riskScore += 26;
    drivers.push(`Elevated Transformer Core Temperature (${temp}°C)`);
    actions.push(`Activate auxiliary forced-oil cooling pumps (Stage 2)`);
  } else if (temp >= 36) {
    riskScore += 16;
    drivers.push(`Elevated Operating Temperature (${temp}°C)`);
    actions.push(`Verify oil-cooling radiator heat dissipation`);
  } else {
    riskScore += 3;
  }

  // 3. Voltage Variation: HIGH, ELEVATED, NORMAL, LOW
  if (voltageVar === 'HIGH') {
    riskScore += 20;
    drivers.push(`Abnormal Voltage Variation (HIGH fluctuation on busbar)`);
    actions.push(`Adjust on-load tap changer (OLTC) and dispatch reactive power (VAR) compensation`);
  } else if (voltageVar === 'ELEVATED') {
    riskScore += 10;
    drivers.push(`Moderate Voltage Deviation outside nominal band`);
    actions.push(`Monitor bus voltage regulation margin`);
  } else {
    riskScore += 2;
  }

  // 4. Frequency Drift (Nominal 50.00 Hz)
  const freqDeviation = Math.abs(freq - 50.0);
  if (freqDeviation > 0.25) {
    riskScore += 10;
    drivers.push(`Severe Grid Frequency Deviation (${freq.toFixed(2)} Hz vs 50.00 Hz nominal)`);
    actions.push(`Dispatch spinning reserve generation for frequency stabilization`);
  } else if (freqDeviation > 0.12) {
    riskScore += 5;
  }

  // 5. Total Harmonic Distortion & Vibration
  if (thd > 5.0) {
    riskScore += 6;
    drivers.push(`High Harmonic Distortion (${thd.toFixed(1)}% THD)`);
  }
  if (vibration > 4.0) {
    riskScore += 6;
    drivers.push(`Abnormal Mechanical Vibration in Transformer (${vibration.toFixed(1)} mm/s)`);
    actions.push(`Schedule urgent acoustic/dissolved gas analysis (DGA) check`);
  }

  // Clamp probability between 2% and 99%
  let probability = Math.min(99, Math.max(2, Math.round(riskScore)));

  // Determine Risk Classification
  let riskLevel: RiskLevel = 'LOW';
  let substationStatus: SubstationStatus = 'ONLINE';

  if (probability >= 75) {
    riskLevel = 'HIGH';
    substationStatus = 'ALERT';
  } else if (probability >= 50) {
    riskLevel = 'HIGH';
    substationStatus = 'WARNING';
  } else if (probability >= 25) {
    riskLevel = 'MODERATE';
    substationStatus = 'ONLINE';
  } else {
    riskLevel = 'LOW';
    substationStatus = 'ONLINE';
  }

  // If probability exceeds 88%, classify as CRITICAL
  if (probability >= 88) {
    riskLevel = 'CRITICAL';
    substationStatus = 'ALERT';
  }

  if (actions.length === 0) {
    actions.push(`Maintain standard telemetry polling; parameters within normal tolerance.`);
  }

  return { probability, riskLevel, drivers, actions, substationStatus };
}

// In-Memory Ground Truth Store for Grid Telemetry
class GridEngine {
  private zones: GridZone[];
  private lastModelRun: string;
  private readonly modelVersion = 'GridGuard-XGB-v4.2.8';

  constructor() {
    this.lastModelRun = new Date().toISOString();
    this.zones = [
      {
        id: 'zone-1',
        name: 'Zone 1 - Downtown Metro Substation',
        shortCode: 'Zone 1',
        substationType: '230kV / 33kV Main Step-Down',
        failureProbability: 12,
        riskLevel: 'LOW',
        loadPercentage: 62,
        temperature: 28,
        voltageVariation: 'NORMAL',
        voltageKv: 229.4,
        nominalVoltageKv: 230,
        frequencyHz: 50.01,
        harmonicDistortionThd: 1.8,
        transformerVibrationMmS: 1.2,
        substationStatus: 'ONLINE',
        capacityMw: 600,
        currentDemandMw: 372,
        primaryRiskDrivers: ['Nominal baseline operating metrics'],
        recommendedActions: ['Maintain standard telemetry polling; parameters within normal tolerance.'],
        coordinates: { x: 220, y: 140 },
        connectedZoneIds: ['zone-2', 'zone-3'],
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 'zone-2',
        name: 'Zone 2 - Industrial Harbor Grid',
        shortCode: 'Zone 2',
        substationType: '115kV Heavy Industrial Feeder',
        failureProbability: 36,
        riskLevel: 'MODERATE',
        loadPercentage: 74,
        temperature: 34,
        voltageVariation: 'ELEVATED',
        voltageKv: 112.1,
        nominalVoltageKv: 115,
        frequencyHz: 49.94,
        harmonicDistortionThd: 4.2,
        transformerVibrationMmS: 2.8,
        substationStatus: 'ONLINE',
        capacityMw: 480,
        currentDemandMw: 355.2,
        primaryRiskDrivers: [
          'High Feeder Load (74%) near peak operational limit',
          'Moderate Voltage Deviation outside nominal band',
          'Industrial induction motor reactive draw'
        ],
        recommendedActions: [
          'Monitor bus voltage regulation margin and capacitor banks',
          'Engage local harmonic filters on industrial feeder line 2A'
        ],
        coordinates: { x: 500, y: 120 },
        connectedZoneIds: ['zone-1', 'zone-4'],
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 'zone-3',
        name: 'Zone 3 - Tech Corridor Substation',
        shortCode: 'Zone 3',
        substationType: '230kV Dual-Redundant Data Center Feed',
        failureProbability: 8,
        riskLevel: 'LOW',
        loadPercentage: 58,
        temperature: 26,
        voltageVariation: 'NORMAL',
        voltageKv: 230.2,
        nominalVoltageKv: 230,
        frequencyHz: 50.00,
        harmonicDistortionThd: 1.4,
        transformerVibrationMmS: 0.9,
        substationStatus: 'ONLINE',
        capacityMw: 520,
        currentDemandMw: 301.6,
        primaryRiskDrivers: ['All primary indicators optimal', 'Redundant N-1 capacity active'],
        recommendedActions: ['Standard routine maintenance cycle.'],
        coordinates: { x: 160, y: 320 },
        connectedZoneIds: ['zone-1', 'zone-5'],
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 'zone-4',
        name: 'Zone 4 - Highland Substation',
        shortCode: 'Zone 4',
        substationType: '230kV / 66kV Regional Intertie',
        // Ground truth explicitly specified in user requirements:
        // Failure probability: 78%
        // Risk: HIGH
        // Load: 91%
        // Temperature: 42°C
        // Voltage variation: HIGH
        failureProbability: 78,
        riskLevel: 'HIGH',
        loadPercentage: 91,
        temperature: 42,
        voltageVariation: 'HIGH',
        voltageKv: 213.8,
        nominalVoltageKv: 230,
        frequencyHz: 49.78,
        harmonicDistortionThd: 6.4,
        transformerVibrationMmS: 4.8,
        substationStatus: 'ALERT',
        capacityMw: 450,
        currentDemandMw: 409.5,
        primaryRiskDrivers: [
          'Extreme Load Saturation (91%) exceeding thermal envelope',
          'Elevated Transformer Core Temperature (42°C)',
          'Abnormal Voltage Variation (HIGH fluctuation on busbar)',
          'High mechanical vibration (4.8 mm/s) on primary step-down unit'
        ],
        recommendedActions: [
          'Initiate immediate load shedding (25 MW) to auxiliary feeders',
          'Activate auxiliary forced-oil cooling pumps (Stage 2)',
          'Adjust on-load tap changer (OLTC) and dispatch reactive power (VAR) compensation',
          'Reroute 18 MW capacity through Zone 2 interconnection tie-line'
        ],
        coordinates: { x: 440, y: 310 },
        connectedZoneIds: ['zone-2', 'zone-5', 'zone-6'],
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 'zone-5',
        name: 'Zone 5 - Valley Residential Feeder',
        shortCode: 'Zone 5',
        substationType: '66kV / 11kV Distribution Network',
        failureProbability: 15,
        riskLevel: 'LOW',
        loadPercentage: 52,
        temperature: 27,
        voltageVariation: 'NORMAL',
        voltageKv: 66.1,
        nominalVoltageKv: 66,
        frequencyHz: 50.02,
        harmonicDistortionThd: 2.1,
        transformerVibrationMmS: 1.1,
        substationStatus: 'ONLINE',
        capacityMw: 320,
        currentDemandMw: 166.4,
        primaryRiskDrivers: ['Off-peak daylight residential profile'],
        recommendedActions: ['Maintain standard telemetry polling; parameters within normal tolerance.'],
        coordinates: { x: 260, y: 470 },
        connectedZoneIds: ['zone-3', 'zone-4'],
        lastUpdated: new Date().toISOString(),
      },
      {
        id: 'zone-6',
        name: 'Zone 6 - West Ridge Renewable Hub',
        shortCode: 'Zone 6',
        substationType: '115kV Wind & Solar Collector Substation',
        failureProbability: 54,
        riskLevel: 'HIGH',
        loadPercentage: 83,
        temperature: 39,
        voltageVariation: 'ELEVATED',
        voltageKv: 111.4,
        nominalVoltageKv: 115,
        frequencyHz: 49.88,
        harmonicDistortionThd: 5.1,
        transformerVibrationMmS: 3.4,
        substationStatus: 'WARNING',
        capacityMw: 380,
        currentDemandMw: 315.4,
        primaryRiskDrivers: [
          'Solar ramp down combined with high gust wind injection (83% load)',
          'Elevated Operating Temperature (39°C)',
          'Harmonic injection from inverter switching (5.1% THD)'
        ],
        recommendedActions: [
          'Throttle renewable inverter active ramp rate by 12%',
          'Engage STATCOM dynamic voltage stabilizer'
        ],
        coordinates: { x: 620, y: 420 },
        connectedZoneIds: ['zone-4'],
        lastUpdated: new Date().toISOString(),
      }
    ];
  }

  public getGridStatus(): GridSystemState {
    const totalCapacity = this.zones.reduce((sum, z) => sum + z.capacityMw, 0);
    const totalDemand = this.zones.reduce((sum, z) => sum + z.currentDemandMw, 0);
    const avgFreq = Number((this.zones.reduce((sum, z) => sum + z.frequencyHz, 0) / this.zones.length).toFixed(2));

    const criticalZonesCount = this.zones.filter(z => z.riskLevel === 'CRITICAL').length;
    const highRiskZonesCount = this.zones.filter(z => z.riskLevel === 'HIGH').length;
    const alertCount = this.zones.filter(z => z.substationStatus !== 'ONLINE').length;

    // Overall grid reliability health score (100 - weighted average failure risk)
    const avgRisk = this.zones.reduce((sum, z) => sum + z.failureProbability, 0) / this.zones.length;
    const overallGridHealth = Math.max(0, Math.round(100 - avgRisk));

    return {
      zones: this.zones,
      overallGridHealth,
      totalDemandMw: Math.round(totalDemand),
      totalCapacityMw: totalCapacity,
      averageFrequency: avgFreq,
      activeAlertCount: alertCount,
      criticalZonesCount,
      highRiskZonesCount,
      lastModelRunTimestamp: this.lastModelRun,
      mlModelVersion: this.modelVersion
    };
  }

  public getZoneById(id: string): GridZone | undefined {
    const normalized = id.toLowerCase().replace(/\s+/g, '');
    return this.zones.find(z =>
      z.id.toLowerCase() === normalized ||
      z.shortCode.toLowerCase().replace(/\s+/g, '') === normalized ||
      z.name.toLowerCase().includes(normalized)
    );
  }

  public updateZoneTelemetry(
    id: string,
    updates: Partial<Pick<GridZone, 'loadPercentage' | 'temperature' | 'voltageVariation' | 'frequencyHz' | 'transformerVibrationMmS'>>
  ): GridZone | null {
    const zone = this.getZoneById(id);
    if (!zone) return null;

    if (updates.loadPercentage !== undefined) {
      zone.loadPercentage = Math.min(100, Math.max(0, Math.round(updates.loadPercentage)));
      zone.currentDemandMw = Number(((zone.capacityMw * zone.loadPercentage) / 100).toFixed(1));
    }
    if (updates.temperature !== undefined) {
      zone.temperature = Math.round(updates.temperature);
    }
    if (updates.voltageVariation !== undefined) {
      zone.voltageVariation = updates.voltageVariation;
    }
    if (updates.frequencyHz !== undefined) {
      zone.frequencyHz = Number(updates.frequencyHz.toFixed(2));
    }
    if (updates.transformerVibrationMmS !== undefined) {
      zone.transformerVibrationMmS = Number(updates.transformerVibrationMmS.toFixed(1));
    }

    // Recompute ML Prediction with actual model logic
    const prediction = calculateMLFailurePrediction(
      zone.loadPercentage,
      zone.temperature,
      zone.voltageVariation,
      zone.frequencyHz,
      zone.harmonicDistortionThd,
      zone.transformerVibrationMmS
    );

    zone.failureProbability = prediction.probability;
    zone.riskLevel = prediction.riskLevel;
    zone.primaryRiskDrivers = prediction.drivers;
    zone.recommendedActions = prediction.actions;
    zone.substationStatus = prediction.substationStatus;
    zone.lastUpdated = new Date().toISOString();
    this.lastModelRun = new Date().toISOString();

    return zone;
  }

  public resetToDefault(): GridSystemState {
    const fresh = new GridEngine();
    this.zones = fresh.zones;
    this.lastModelRun = new Date().toISOString();
    return this.getGridStatus();
  }

  // Generates verified, structured telemetry data for Gemini context
  public getTelemetryContextForAI(): string {
    const status = this.getGridStatus();
    const zoneSummaries = this.zones.map(z => {
      return `[${z.shortCode}] (${z.name})
- Failure Probability: ${z.failureProbability}%
- Risk Classification: ${z.riskLevel}
- Substation Status: ${z.substationStatus}
- Feeder Load: ${z.loadPercentage}% (${z.currentDemandMw} MW / ${z.capacityMw} MW)
- Core Temperature: ${z.temperature}°C
- Voltage Variation: ${z.voltageVariation} (Current: ${z.voltageKv} kV / Nominal: ${z.nominalVoltageKv} kV)
- Frequency: ${z.frequencyHz} Hz
- Harmonic Distortion: ${z.harmonicDistortionThd}% THD
- Transformer Vibration: ${z.transformerVibrationMmS} mm/s
- Primary Risk Drivers: ${z.primaryRiskDrivers.join('; ')}
- Recommended Preventive Actions: ${z.recommendedActions.join('; ')}
`;
    }).join('\n');

    return `SYSTEM OVERVIEW:
- Overall Grid Health Score: ${status.overallGridHealth}/100
- Active Alerts: ${status.activeAlertCount}
- Critical Risk Zones: ${status.criticalZonesCount}
- High Risk Zones: ${status.highRiskZonesCount}
- Total Grid Demand: ${status.totalDemandMw} MW / Total Capacity: ${status.totalCapacityMw} MW
- Average Frequency: ${status.averageFrequency} Hz
- ML Model Version: ${status.mlModelVersion}
- Last Model Telemetry Timestamp: ${status.lastModelRunTimestamp}

CURRENT MONITORED ZONES (GROUND TRUTH FROM ML MODEL):
${zoneSummaries}`;
  }
}

export const gridEngine = new GridEngine();
