import { GoogleGenAI } from '@google/genai';
import { gridEngine } from './gridEngine';
import { ChatResponse } from '../src/types';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function processGridGuardChat(
  userMessage: string,
  history: Array<{ sender: 'user' | 'assistant'; text: string }> = []
): Promise<ChatResponse> {
  const ai = getAiClient();
  const gridTelemetryContext = gridEngine.getTelemetryContextForAI();
  const currentStatus = gridEngine.getGridStatus();

  // Identify any referenced zones in user message or context
  const referencedZones: string[] = [];
  for (const zone of currentStatus.zones) {
    const regex = new RegExp(`\\b(${zone.shortCode}|${zone.id})\\b`, 'i');
    if (regex.test(userMessage)) {
      referencedZones.push(zone.shortCode);
    }
  }

  // If Gemini API Key is available, use Gemini 3.8 Flash with verified ML ground truth
  if (ai) {
    try {
      const systemInstruction = `You are Bob AI Assistant, the specialized AI diagnostic assistant integrated into the Grid Failure Prediction System.

CORE MISSION & NON-NEGOTIABLE GROUND RULES:
1. THE ML MODEL IS THE SOLE SOURCE OF TRUTH:
   - All failure probabilities (%), risk levels (LOW, MODERATE, HIGH, CRITICAL), sensor values (load %, temperature °C, voltage variation, frequency Hz, vibration), and predictions must come directly from the verified telemetry provided below.
   - NEVER hallucinate, estimate, or invent prediction percentages or sensor values.
   - For example, if Zone 4 has a 78% failure risk, load 91%, temperature 42°C, and HIGH voltage variation, state exactly 78% and those exact sensor values.
2. MISSING DATA HANDLING:
   - If the user asks about a zone, feeder, or metric not present in the verified telemetry data below (e.g., "Zone 9" or "transformer oil moisture in Zone 1"), explicitly state that the telemetry or zone is unavailable or unmonitored in the current monitoring system, rather than guessing.
3. PROFESSIONAL SYSTEM TONE:
   - Maintain a crisp, authoritative, clear, and analytical power-grid engineering tone suitable for SCADA / transmission grid operators. Introduce yourself as Bob AI Assistant if asked who you are.
   - Do NOT use emojis, hype, or conversational fluff.
   - Keep answers direct, technically precise, and actionable.
4. ACTIONABLE PREVENTIVE PROTOCOLS:
   - When asked about preventive action, mitigation, or what to do, cite the system's verified recommended engineering actions (such as load shedding MW, tap changer adjustments, forced-oil cooling pumps, or tie-line power rerouting).
5. ZONE COMPARISONS:
   - When asked to compare zones (e.g. "Compare Zone 2 and Zone 4"), provide a side-by-side metric comparison (Failure Risk %, Load %, Core Temp, Voltage Status, Primary Risk Factor) directly from the model.

CURRENT VERIFIED GRID TELEMETRY & ML MODEL GROUND TRUTH:
=====================================================
${gridTelemetryContext}
=====================================================`;

      // Build conversation context
      const formattedHistory = history.slice(-6).map(msg => 
        `${msg.sender === 'user' ? 'Operator' : 'Bob AI Assistant'}: ${msg.text}`
      ).join('\n');

      const fullPrompt = `${formattedHistory ? `RECENT CONVERSATION HISTORY:\n${formattedHistory}\n\n` : ''}Operator Question: ${userMessage}

Bob AI Assistant Response:`;

      let responseText = '';
      const candidateModels = ['gemini-3.8-flash', 'gemini-3.6-flash'];

      for (const model of candidateModels) {
        try {
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout on ${model}`)), 8000)
          );

          const generatePromise = ai.models.generateContent({
            model,
            contents: fullPrompt,
            config: {
              systemInstruction,
              temperature: 0.2, // Low temperature for high factual precision
            },
          });

          const response = await Promise.race([generatePromise, timeoutPromise]);
          if (response && response.text) {
            responseText = response.text;
            break;
          }
        } catch (modelErr: any) {
          console.warn(`Model ${model} unavailable (${modelErr?.status || modelErr?.message}), trying next fallback...`);
        }
      }

      if (!responseText) {
        throw new Error('All Gemini candidate models returned empty or failed');
      }

      // Extract referenced zones if mentioned in response
      for (const zone of currentStatus.zones) {
        if (!referencedZones.includes(zone.shortCode)) {
          const zoneRegex = new RegExp(`\\b${zone.shortCode}\\b`, 'i');
          if (zoneRegex.test(responseText)) {
            referencedZones.push(zone.shortCode);
          }
        }
      }

      return {
        response: responseText.trim(),
        referencedZones,
        timestamp: new Date().toISOString(),
        source: 'gemini',
      };
    } catch (error) {
      console.error('Gemini API query error, falling back to ML Engine Diagnostic Synthesizer:', error);
      // Fallback gracefully to the deterministic ML diagnostic engine
      return generateRuleEngineResponse(userMessage, currentStatus, referencedZones);
    }
  }

  // Deterministic ML Diagnostic Engine fallback if GEMINI_API_KEY is not set
  return generateRuleEngineResponse(userMessage, currentStatus, referencedZones);
}

function generateRuleEngineResponse(
  userMessage: string,
  currentStatus: ReturnType<typeof gridEngine.getGridStatus>,
  referencedZones: string[]
): ChatResponse {
  const lower = userMessage.toLowerCase();
  let responseText = '';

  // 1. Highest risk inquiry
  if (lower.includes('highest') || lower.includes('most dangerous') || lower.includes('worst')) {
    const highestRiskZone = [...currentStatus.zones].sort((a, b) => b.failureProbability - a.failureProbability)[0];
    if (highestRiskZone) {
      if (!referencedZones.includes(highestRiskZone.shortCode)) {
        referencedZones.push(highestRiskZone.shortCode);
      }
      responseText = `**${highestRiskZone.shortCode} (${highestRiskZone.name})** currently has the highest failure risk in the system with a predicted failure probability of **${highestRiskZone.failureProbability}%** (${highestRiskZone.riskLevel} Risk).

**Primary Telemetry Factors:**
- **Load:** ${highestRiskZone.loadPercentage}% (${highestRiskZone.currentDemandMw} MW / ${highestRiskZone.capacityMw} MW)
- **Temperature:** ${highestRiskZone.temperature}°C
- **Voltage Variation:** ${highestRiskZone.voltageVariation} (${highestRiskZone.voltageKv} kV)
- **Frequency:** ${highestRiskZone.frequencyHz} Hz
- **Vibration:** ${highestRiskZone.transformerVibrationMmS} mm/s

**Recommended Immediate Action:**
${highestRiskZone.recommendedActions.map(a => `- ${a}`).join('\n')}`;
    }
  }
  // 2. "Why is Zone X high risk?"
  else if (lower.includes('why') && (lower.includes('zone 4') || lower.includes('zone-4') || lower.includes('highland'))) {
    const zone4 = currentStatus.zones.find(z => z.shortCode === 'Zone 4')!;
    if (!referencedZones.includes('Zone 4')) referencedZones.push('Zone 4');
    responseText = `${zone4.shortCode} currently has a **${zone4.failureProbability}%** predicted failure risk and is classified as **${zone4.riskLevel} Risk**.

The elevated risk is associated with **high load (${zone4.loadPercentage}%)**, **abnormal voltage variation (${zone4.voltageVariation})**, and **elevated temperature (${zone4.temperature}°C)**.

**Detailed Sensor Telemetry:**
- **Load Saturation:** ${zone4.loadPercentage}% (${zone4.currentDemandMw} MW / ${zone4.capacityMw} MW)
- **Transformer Core Temp:** ${zone4.temperature}°C
- **Voltage Fluctuation:** ${zone4.voltageVariation} at ${zone4.voltageKv} kV (Nominal: ${zone4.nominalVoltageKv} kV)
- **Vibration:** ${zone4.transformerVibrationMmS} mm/s (threshold: 4.0 mm/s)

**Recommended Preventive Protocols:**
${zone4.recommendedActions.map(a => `- ${a}`).join('\n')}`;
  }
  // 3. Comparison (e.g. Compare Zone 2 and Zone 4)
  else if (lower.includes('compare') || (lower.includes('zone 2') && lower.includes('zone 4')) || (referencedZones.length >= 2)) {
    const z2 = currentStatus.zones.find(z => z.shortCode === 'Zone 2') || currentStatus.zones[1];
    const z4 = currentStatus.zones.find(z => z.shortCode === 'Zone 4') || currentStatus.zones[3];
    if (!referencedZones.includes(z2.shortCode)) referencedZones.push(z2.shortCode);
    if (!referencedZones.includes(z4.shortCode)) referencedZones.push(z4.shortCode);

    responseText = `**Comparative Reliability Analysis: ${z2.shortCode} vs ${z4.shortCode}**

| Telemetry Parameter | ${z2.shortCode} (${z2.name.split(' - ')[1] || z2.name}) | ${z4.shortCode} (${z4.name.split(' - ')[1] || z4.name}) |
| :--- | :--- | :--- |
| **Failure Probability** | **${z2.failureProbability}%** | **${z4.failureProbability}%** |
| **Risk Classification** | ${z2.riskLevel} | **${z4.riskLevel}** |
| **Load Factor** | ${z2.loadPercentage}% (${z2.currentDemandMw} MW) | **${z4.loadPercentage}% (${z4.currentDemandMw} MW)** |
| **Core Temperature** | ${z2.temperature}°C | **${z4.temperature}°C** |
| **Voltage Variation** | ${z2.voltageVariation} | **${z4.voltageVariation}** |
| **Substation Status** | ${z2.substationStatus} | **${z4.substationStatus}** |

**Summary:**
Zone 4 is in a significantly higher risk state (+${z4.failureProbability - z2.failureProbability}% probability) due to extreme load saturation (${z4.loadPercentage}%) and critical core temperature (${z4.temperature}°C). Zone 2 is under moderate stress (${z2.loadPercentage}% load) but within thermal tolerance.`;
  }
  // 4. Any specific single zone query (e.g. Zone 1, Zone 2, Zone 3, etc.)
  else if (referencedZones.length === 1 || /zone\s*(\d)/i.test(lower)) {
    const match = lower.match(/zone\s*(\d)/i);
    const zoneNum = match ? match[1] : referencedZones[0]?.replace(/\D/g, '');
    const zone = currentStatus.zones.find(z => z.shortCode.toLowerCase() === `zone ${zoneNum}`);

    if (zone) {
      if (!referencedZones.includes(zone.shortCode)) referencedZones.push(zone.shortCode);
      responseText = `**${zone.shortCode} Status & Risk Diagnostics:**
- **Failure Probability:** **${zone.failureProbability}%** (${zone.riskLevel} Risk)
- **Substation Status:** ${zone.substationStatus}
- **Feeder Load:** ${zone.loadPercentage}% (${zone.currentDemandMw} MW / ${zone.capacityMw} MW)
- **Transformer Temperature:** ${zone.temperature}°C
- **Voltage Variation:** ${zone.voltageVariation} (${zone.voltageKv} kV)
- **Frequency:** ${zone.frequencyHz} Hz

**Risk Analysis:**
${zone.primaryRiskDrivers.map(d => `- ${d}`).join('\n')}

**Recommended Actions:**
${zone.recommendedActions.map(a => `- ${a}`).join('\n')}`;
    } else {
      responseText = `Telemetry data for Zone ${zoneNum} is currently unavailable in the GridGuard monitoring network. Please select from monitored zones (Zone 1 through Zone 6).`;
    }
  }
  // 5. Critical or high risk zones
  else if (lower.includes('critical') || lower.includes('alert') || lower.includes('warning')) {
    const criticalOrHigh = currentStatus.zones.filter(z => z.riskLevel === 'CRITICAL' || z.riskLevel === 'HIGH');
    criticalOrHigh.forEach(z => {
      if (!referencedZones.includes(z.shortCode)) referencedZones.push(z.shortCode);
    });

    responseText = `**Critical & High-Risk Zones (${criticalOrHigh.length} Detected):**

${criticalOrHigh.map(z => `• **${z.shortCode} (${z.name})**: **${z.failureProbability}%** failure risk (${z.riskLevel}). Load: ${z.loadPercentage}%, Temp: ${z.temperature}°C, Voltage: ${z.voltageVariation}. Primary concern: ${z.primaryRiskDrivers[0]}`).join('\n\n')}

All other zones (${currentStatus.zones.length - criticalOrHigh.length}) are operating within nominal or moderate tolerance margins.`;
  }
  // 6. Preventive actions recommended
  else if (lower.includes('preventive') || lower.includes('action') || lower.includes('mitigat') || lower.includes('recommend')) {
    const stressedZones = currentStatus.zones.filter(z => z.failureProbability >= 30);
    stressedZones.forEach(z => {
      if (!referencedZones.includes(z.shortCode)) referencedZones.push(z.shortCode);
    });

    responseText = `**System-Wide Recommended Preventive Protocols:**

${stressedZones.map(z => `**${z.shortCode} (${z.failureProbability}% Failure Risk):**
${z.recommendedActions.map(a => `- ${a}`).join('\n')}`).join('\n\n')}

Implementing these actions will reduce peak thermal loading and stabilize regional grid frequency back to 50.00 Hz.`;
  }
  // 7. Identity inquiries
  else if (lower.includes('who are you') || lower.includes('your name') || lower.includes('what are you')) {
    responseText = `I am **Bob AI Assistant**, the specialized AI diagnostic assistant for the Grid Failure Prediction System.

I analyze real-time SCADA telemetry and ML predictive models across all monitored transmission zones (Zone 1 through Zone 6) to diagnose failure risks, identify primary stress drivers (such as feeder overload, thermal excursions, and voltage fluctuations), and provide actionable preventive protocols.`;
  }
  // 8. General grid status
  else {
    responseText = `**Bob AI Assistant - Grid Status Overview:**
- **Overall Grid Reliability Health:** **${currentStatus.overallGridHealth}/100**
- **Active Grid Alerts:** ${currentStatus.activeAlertCount} zones requiring intervention
- **Total System Demand:** ${currentStatus.totalDemandMw} MW / ${currentStatus.totalCapacityMw} MW nominal capacity
- **Average Frequency:** ${currentStatus.averageFrequency} Hz (Nominal: 50.00 Hz)
- **Model Engine:** ${currentStatus.mlModelVersion}

**Zone Breakdown:**
${currentStatus.zones.map(z => `- **${z.shortCode}**: ${z.failureProbability}% failure probability (${z.riskLevel} Risk)`).join('\n')}

You can ask for specific root-cause analysis (e.g., *"Why is Zone 4 high risk?"*), comparative telemetry (*"Compare Zone 2 and Zone 4"*), or recommended preventive actions.`;
  }

  return {
    response: responseText,
    referencedZones,
    timestamp: new Date().toISOString(),
    source: 'rule_engine_fallback',
  };
}
