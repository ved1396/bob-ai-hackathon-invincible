import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { gridEngine } from './server/gridEngine';
import { processGridGuardChat } from './server/geminiService';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Endpoints ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
    });
  });

  // Get full GridGuard status & ML predictions
  app.get('/api/grid/status', (req, res) => {
    try {
      const status = gridEngine.getGridStatus();
      res.json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to retrieve grid status' });
    }
  });

  // Get single zone telemetry
  app.get('/api/grid/zones/:id', (req, res) => {
    try {
      const zone = gridEngine.getZoneById(req.params.id);
      if (!zone) {
        return res.status(404).json({ error: `Zone ${req.params.id} not found` });
      }
      res.json(zone);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update telemetry & run ML model recalculation
  app.post('/api/grid/telemetry', (req, res) => {
    try {
      const { id, loadPercentage, temperature, voltageVariation, frequencyHz, transformerVibrationMmS } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'Zone ID is required' });
      }

      const updatedZone = gridEngine.updateZoneTelemetry(id, {
        loadPercentage: loadPercentage !== undefined ? Number(loadPercentage) : undefined,
        temperature: temperature !== undefined ? Number(temperature) : undefined,
        voltageVariation,
        frequencyHz: frequencyHz !== undefined ? Number(frequencyHz) : undefined,
        transformerVibrationMmS: transformerVibrationMmS !== undefined ? Number(transformerVibrationMmS) : undefined,
      });

      if (!updatedZone) {
        return res.status(404).json({ error: `Zone ${id} not found` });
      }

      const status = gridEngine.getGridStatus();
      res.json({ zone: updatedZone, gridStatus: status });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Reset grid telemetry to standard baseline
  app.post('/api/grid/reset', (req, res) => {
    try {
      const status = gridEngine.resetToDefault();
      res.json(status);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Preset stress simulation scenarios
  app.post('/api/grid/simulate', (req, res) => {
    try {
      const { scenario } = req.body;
      if (scenario === 'heatwave') {
        gridEngine.updateZoneTelemetry('zone-4', { temperature: 46, loadPercentage: 96, voltageVariation: 'HIGH' });
        gridEngine.updateZoneTelemetry('zone-2', { temperature: 41, loadPercentage: 86, voltageVariation: 'ELEVATED' });
        gridEngine.updateZoneTelemetry('zone-6', { temperature: 44, loadPercentage: 89, voltageVariation: 'HIGH' });
      } else if (scenario === 'mitigated') {
        // Operator applied recommended cooling & load shed on Zone 4
        gridEngine.updateZoneTelemetry('zone-4', { temperature: 33, loadPercentage: 74, voltageVariation: 'NORMAL' });
      } else if (scenario === 'severe_contingency') {
        // High risk cascade
        gridEngine.updateZoneTelemetry('zone-4', { temperature: 48, loadPercentage: 98, voltageVariation: 'HIGH', transformerVibrationMmS: 5.6 });
        gridEngine.updateZoneTelemetry('zone-2', { temperature: 42, loadPercentage: 92, voltageVariation: 'HIGH' });
      } else {
        gridEngine.resetToDefault();
      }

      const status = gridEngine.getGridStatus();
      res.json({ success: true, scenario, gridStatus: status });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/chat - GridGuard AI Assistant
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history = [] } = req.body;
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Valid message string is required' });
      }

      const chatResult = await processGridGuardChat(message, history);
      res.json(chatResult);
    } catch (err: any) {
      console.error('Chat endpoint error:', err);
      res.status(500).json({
        error: 'Failed to process chat query',
        details: err.message || String(err),
      });
    }
  });

  // --- Vite & Static Asset Handling ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GridGuard Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start GridGuard server:', err);
  process.exit(1);
});
