export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type VoltageVariation = 'LOW' | 'NORMAL' | 'ELEVATED' | 'HIGH';
export type SubstationStatus = 'ONLINE' | 'WARNING' | 'ALERT' | 'TRIPPED';

export interface GridZone {
  id: string;
  name: string;
  shortCode: string;
  substationType: string;
  failureProbability: number; // 0 - 100 (%)
  riskLevel: RiskLevel;
  loadPercentage: number; // 0 - 100 (%)
  temperature: number; // °C
  voltageVariation: VoltageVariation;
  voltageKv: number; // e.g. 214.2 on 230 nominal
  nominalVoltageKv: number;
  frequencyHz: number; // e.g. 49.82 on 50.00
  harmonicDistortionThd: number; // %
  transformerVibrationMmS: number; // mm/s
  substationStatus: SubstationStatus;
  capacityMw: number;
  currentDemandMw: number;
  primaryRiskDrivers: string[];
  recommendedActions: string[];
  coordinates: { x: number; y: number };
  connectedZoneIds: string[];
  lastUpdated: string;
}

export interface GridSystemState {
  zones: GridZone[];
  overallGridHealth: number; // 0 - 100
  totalDemandMw: number;
  totalCapacityMw: number;
  averageFrequency: number;
  activeAlertCount: number;
  criticalZonesCount: number;
  highRiskZonesCount: number;
  lastModelRunTimestamp: string;
  mlModelVersion: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  referencedZones?: string[];
  keyMetrics?: Array<{
    label: string;
    value: string;
    severity?: 'normal' | 'warning' | 'critical';
  }>;
}

export interface ChatRequest {
  message: string;
  history?: Array<{
    sender: 'user' | 'assistant';
    text: string;
  }>;
  selectedZoneId?: string;
}

export interface ChatResponse {
  response: string;
  referencedZones?: string[];
  timestamp: string;
  source: 'gemini' | 'rule_engine_fallback';
}
