import React from 'react';
import { ShieldAlert, Activity, Cpu, RotateCcw, Flame, Bot, Zap, CheckCircle2 } from 'lucide-react';
import { GridSystemState } from '../types';

interface GridHeaderProps {
  gridState: GridSystemState | null;
  isLoading: boolean;
  onReset: () => void;
  onSimulate: (scenario: 'heatwave' | 'mitigated' | 'severe_contingency') => void;
  onOpenChat: (initialQuery?: string) => void;
  isChatOpen: boolean;
}

export const GridHeader: React.FC<GridHeaderProps> = ({
  gridState,
  isLoading,
  onReset,
  onSimulate,
  onOpenChat,
  isChatOpen,
}) => {
  const healthColor = !gridState
    ? 'text-slate-400'
    : gridState.overallGridHealth > 75
    ? 'text-emerald-400'
    : gridState.overallGridHealth > 50
    ? 'text-amber-400'
    : 'text-rose-400';

  return (
    <header className="border-b border-slate-800 bg-[#0d1322]/90 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo & Substation Info */}
          <div className="flex items-center space-x-3.5">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
              <Zap className="w-5 h-5" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-tight text-white font-mono">
                  GRID<span className="text-cyan-400">GUARD</span>
                </h1>
                <span className="text-[10px] uppercase font-semibold tracking-wider px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  ML Failure Prediction
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-1.5 font-mono">
                <span>SCADA Intertie Network</span>
                <span className="text-slate-600">•</span>
                <span className="text-cyan-400/80">Model {gridState?.mlModelVersion || 'v4.2.8'}</span>
              </p>
            </div>
          </div>

          {/* Key SCADA Telemetry Metrics */}
          {gridState && (
            <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs font-mono">
              {/* Reliability Health */}
              <div className="px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400">Health Index:</span>
                <span className={`font-bold ${healthColor}`}>
                  {gridState.overallGridHealth}%
                </span>
              </div>

              {/* Grid Frequency */}
              <div className="px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-slate-400">Freq:</span>
                <span className={`font-bold ${Math.abs(gridState.averageFrequency - 50.0) > 0.15 ? 'text-amber-400' : 'text-slate-200'}`}>
                  {gridState.averageFrequency} Hz
                </span>
              </div>

              {/* System Load */}
              <div className="px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                <span className="text-slate-400">Demand:</span>
                <span className="font-bold text-slate-200">
                  {gridState.totalDemandMw} <span className="text-[10px] text-slate-400 font-normal">/ {gridState.totalCapacityMw} MW</span>
                </span>
              </div>

              {/* Critical / Alerts Badge */}
              <div className={`px-3 py-1.5 rounded-md border flex items-center gap-1.5 ${
                gridState.activeAlertCount > 0 
                  ? 'bg-rose-950/40 border-rose-800/60 text-rose-300' 
                  : 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
              }`}>
                {gridState.activeAlertCount > 0 ? (
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                )}
                <span className="font-semibold">
                  {gridState.activeAlertCount} {gridState.activeAlertCount === 1 ? 'Alert' : 'Alerts'}
                </span>
              </div>
            </div>
          )}

          {/* Quick Simulation & AI Assistant Access */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSimulate('heatwave')}
              title="Simulate severe summer heatwave stress"
              className="px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Simulate</span> Heatwave
            </button>

            <button
              onClick={onReset}
              title="Reset telemetry to baseline ground truth (Zone 4 = 78% risk)"
              className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-md bg-slate-800/70 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>

            <button
              onClick={() => onOpenChat()}
              className={`px-3 py-1.5 rounded-md font-medium text-xs transition-all flex items-center gap-2 cursor-pointer shadow-sm ${
                isChatOpen
                  ? 'bg-cyan-500 text-slate-950 ring-2 ring-cyan-400/50'
                  : 'bg-cyan-950/80 hover:bg-cyan-900/90 text-cyan-300 border border-cyan-700/60'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span className="font-semibold">Bob AI Assistant</span>
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping hidden sm:inline-block" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
