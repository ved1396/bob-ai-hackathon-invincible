import React, { useState, useRef, useEffect } from 'react';
import Markdown from 'react-markdown';
import { 
  Bot, 
  Send, 
  Trash2, 
  X, 
  Maximize2, 
  Minimize2, 
  AlertCircle, 
  CornerDownLeft, 
  Sparkles,
  Zap,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';
import { ChatMessage, ChatResponse, GridZone } from '../types';

interface GridGuardChatbotProps {
  isOpen: boolean;
  onToggleOpen: () => void;
  onSelectZoneByCode: (code: string) => void;
  externalQuery?: string | null;
  onClearExternalQuery?: () => void;
}

const SUGGESTED_QUESTIONS = [
  "Which zone has the highest failure risk?",
  "Why is Zone 4 high risk?",
  "What is the current grid status?",
  "Which zones are critical?",
  "What factors are causing the risk?",
  "What preventive action should be taken?",
  "Compare Zone 2 and Zone 4."
];

export const GridGuardChatbot: React.FC<GridGuardChatbotProps> = ({
  isOpen,
  onToggleOpen,
  onSelectZoneByCode,
  externalQuery,
  onClearExternalQuery,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: `**Bob AI Assistant Online.** Verified connection established with the Grid Failure Prediction ML engine.

Ask any diagnostic inquiry regarding monitored substation zones, real-time telemetry, failure probability rankings, or recommended preventive protocols.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom whenever messages update
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      // Focus input when opened
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, messages, isLoading]);

  // Handle queries passed from external buttons (e.g. from Zone cards)
  useEffect(() => {
    if (externalQuery && externalQuery.trim()) {
      if (!isOpen) {
        onToggleOpen();
      }
      handleSendMessage(externalQuery);
      if (onClearExternalQuery) {
        onClearExternalQuery();
      }
    }
  }, [externalQuery]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isLoading) return;

    setErrorMessage(null);
    setInputMessage('');

    const userMessageObj: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const nextMessages = [...messages, userMessageObj];
    setMessages(nextMessages);
    setIsLoading(true);

    try {
      // Build conversation history format for the API
      const historyPayload = messages
        .filter((m) => m.id !== 'welcome-1')
        .slice(-6)
        .map((m) => ({
          sender: m.sender,
          text: m.text,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: historyPayload,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with ${res.status}`);
      }

      const data: ChatResponse = await res.json();

      const assistantMessageObj: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        referencedZones: data.referencedZones,
      };

      setMessages((prev) => [...prev, assistantMessageObj]);
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorMessage(err.message || 'Unable to communicate with GridGuard AI service.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        sender: 'assistant',
        text: `**Chat history cleared.** Ready for diagnostic inquiries on the grid failure prediction system.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setErrorMessage(null);
  };

  return (
    <>
      {/* Floating Chatbot Trigger Button (Bottom Right) */}
      {!isOpen && (
        <button
          onClick={onToggleOpen}
          className="fixed bottom-6 right-6 z-40 p-3.5 sm:px-4 sm:py-3 rounded-full bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold shadow-2xl flex items-center gap-2.5 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer border border-cyan-400/40"
          aria-label="Open Bob AI Assistant"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-slate-950" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-slate-950" />
          </div>
          <span className="hidden sm:inline font-mono text-xs tracking-wider uppercase font-extrabold">
            Bob AI Assistant
          </span>
        </button>
      )}

      {/* Expandable Chatbot Panel */}
      {isOpen && (
        <div
          className={`fixed z-50 transition-all duration-200 flex flex-col bg-[#0d1322] border border-cyan-500/40 shadow-2xl overflow-hidden font-mono ${
            isExpanded
              ? 'inset-3 sm:inset-6 rounded-xl'
              : 'bottom-4 right-4 sm:bottom-6 sm:right-6 w-[95vw] sm:w-[480px] h-[580px] max-h-[88vh] rounded-xl'
          }`}
        >
          {/* Header */}
          <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between select-none">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                  <span>Bob AI Assistant</span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-cyan-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>AI Assistant</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-slate-400 text-[10px]">Gemini 3.8 Flash + ML Ground Truth</span>
                </div>
              </div>
            </div>

            {/* Header Controls */}
            <div className="flex items-center gap-1 text-slate-400">
              <button
                onClick={handleClearChat}
                title="Clear current-session chat history"
                className="p-1.5 rounded hover:bg-slate-800 hover:text-slate-200 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsExpanded(!isExpanded)}
                title={isExpanded ? 'Restore window size' : 'Expand window'}
                className="p-1.5 rounded hover:bg-slate-800 hover:text-slate-200 transition-colors hidden sm:inline-block cursor-pointer"
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>

              <button
                onClick={onToggleOpen}
                title="Minimize chatbot"
                className="p-1.5 rounded hover:bg-slate-800 hover:text-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Suggested Questions Horizontal Bar */}
          <div className="px-3 py-2 bg-slate-950/70 border-b border-slate-800/80 overflow-x-auto whitespace-nowrap scrollbar-none flex items-center gap-1.5">
            <span className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1 flex-shrink-0 mr-1">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              Suggested:
            </span>
            {SUGGESTED_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(q)}
                disabled={isLoading}
                className="px-2.5 py-1 rounded bg-slate-900 hover:bg-cyan-950/80 text-slate-300 hover:text-cyan-300 border border-slate-800 hover:border-cyan-700/60 text-[11px] transition-all cursor-pointer flex-shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#080d1a] text-xs">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[90%] rounded-xl px-3.5 py-2.5 shadow-md ${
                      isUser
                        ? 'bg-cyan-600 text-slate-950 font-medium rounded-br-none'
                        : 'bg-slate-900/90 text-slate-200 border border-slate-800 rounded-bl-none'
                    }`}
                  >
                    {!isUser ? (
                      <div className="chat-markdown text-slate-200 text-xs">
                        <Markdown>{msg.text}</Markdown>
                      </div>
                    ) : (
                      <div className="whitespace-pre-wrap">{msg.text}</div>
                    )}

                    {/* Referenced Zone Quick Jump Pills */}
                    {!isUser && msg.referencedZones && msg.referencedZones.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-slate-400 font-semibold">
                          Monitored Entities:
                        </span>
                        {msg.referencedZones.map((zoneCode) => (
                          <button
                            key={zoneCode}
                            onClick={() => onSelectZoneByCode(zoneCode)}
                            className="px-2 py-0.5 rounded bg-cyan-950/70 hover:bg-cyan-900 text-cyan-300 border border-cyan-700/50 text-[10px] font-bold transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Zap className="w-2.5 h-2.5" />
                            <span>Inspect {zoneCode}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <span className="text-[10px] text-slate-500 mt-1 px-1">
                    {msg.timestamp}
                  </span>
                </div>
              );
            })}

            {/* Typing / Loading Indicator */}
            {isLoading && (
              <div className="flex flex-col items-start">
                <div className="bg-slate-900/90 border border-slate-800 rounded-xl rounded-bl-none px-3.5 py-2.5 shadow-md flex items-center gap-2 text-cyan-400 text-xs">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Querying verified ML model & SCADA telemetry...
                  </span>
                </div>
              </div>
            )}

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 rounded-lg bg-rose-950/50 border border-rose-800/60 text-rose-300 text-[11px] flex items-start gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-400" />
                <div className="flex-1">
                  <div className="font-bold">Chat Processing Error</div>
                  <div>{errorMessage}</div>
                  <button
                    onClick={() => handleSendMessage()}
                    className="mt-1.5 px-2 py-0.5 bg-rose-900 hover:bg-rose-800 rounded text-[10px] font-semibold text-white cursor-pointer"
                  >
                    Retry Query
                  </button>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box Area */}
          <div className="p-3 bg-[#0a0f1d] border-t border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-end gap-2"
            >
              <div className="flex-1 relative">
                <textarea
                  ref={inputRef}
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask Bob AI Assistant about failure risk, Zone 4, critical zones..."
                  rows={2}
                  disabled={isLoading}
                  className="w-full bg-slate-900/90 text-slate-100 placeholder-slate-500 rounded-lg px-3 py-2 text-xs border border-slate-700/80 focus:outline-none focus:border-cyan-500 resize-none font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={!inputMessage.trim() || isLoading}
                className="p-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:hover:bg-cyan-600 text-slate-950 font-bold transition-all cursor-pointer flex-shrink-0"
                title="Send message (Enter)"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
            <div className="flex justify-between items-center text-[10px] text-slate-500 mt-1.5 px-1">
              <span>Press <kbd className="text-slate-400 font-bold">Enter</kbd> to send, <kbd className="text-slate-400 font-bold">Shift+Enter</kbd> for newline</span>
              <span className="text-slate-500 font-mono">ML Ground Truth Guaranteed</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
