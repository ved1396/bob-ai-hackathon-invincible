import React from 'react';
import { GridZone } from '../types';
import { ShieldAlert, Bot, ArrowRight, Activity } from 'lucide-react';

interface ZonesTableProps {
  zones: GridZone[];
  selectedZoneId?: string;
  onSelectZone: (zone: GridZone) => void;
  onAskAI: (query: string) => void;
}

export const ZonesTable: React.FC<ZonesTableProps> = ({
  zones,
  selectedZoneId,
  onSelectZone,
  onAskAI,
}) => {
  return (
    <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-4 shadow-xl font-mono text-xs overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
        <div>
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            REGIONAL TRANSMISSION ZONES TELEMETRY MATRIX
          </h2>
          <p className="text-slate-400 text-[11px]">
            Comprehensive real-time telemetry and ML failure probability rankings
          </p>
        </div>
        <div className="text-[11px] text-slate-400">
          Click any row to inspect telemetry & trigger what-if analysis
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase">
              <th className="py-2.5 px-3">Zone / Substation</th>
              <th className="py-2.5 px-3">ML Failure Risk</th>
              <th className="py-2.5 px-3">Risk Level</th>
              <th className="py-2.5 px-3">Load (%)</th>
              <th className="py-2.5 px-3">Core Temp</th>
              <th className="py-2.5 px-3">Voltage Var</th>
              <th className="py-2.5 px-3">Substation</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {zones.map((zone) => {
              const isSelected = selectedZoneId === zone.id;
              const isHigh = zone.failureProbability >= 50;

              return (
                <tr
                  key={zone.id}
                  onClick={() => onSelectZone(zone)}
                  className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                    isSelected ? 'bg-cyan-950/30' : ''
                  }`}
                >
                  {/* Zone Name */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-cyan-400">{zone.shortCode}</span>
                      <span className="text-slate-300 hidden md:inline">{zone.name.split(' - ')[1] || zone.name}</span>
                    </div>
                  </td>

                  {/* Failure Risk Probability Bar */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 sm:w-24 bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            isHigh
                              ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]'
                              : zone.failureProbability > 25
                              ? 'bg-amber-400'
                              : 'bg-emerald-400'
                          }`}
                          style={{ width: `${zone.failureProbability}%` }}
                        />
                      </div>
                      <span className={`font-bold ${isHigh ? 'text-rose-400' : 'text-slate-200'}`}>
                        {zone.failureProbability}%
                      </span>
                    </div>
                  </td>

                  {/* Risk Level Badge */}
                  <td className="py-3 px-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${
                        zone.riskLevel === 'CRITICAL'
                          ? 'bg-rose-950/80 text-rose-300 border-rose-600'
                          : zone.riskLevel === 'HIGH'
                          ? 'bg-rose-900/40 text-rose-300 border-rose-700/60'
                          : zone.riskLevel === 'MODERATE'
                          ? 'bg-amber-900/30 text-amber-300 border-amber-600/40'
                          : 'bg-emerald-900/30 text-emerald-300 border-emerald-600/40'
                      }`}
                    >
                      {zone.riskLevel}
                    </span>
                  </td>

                  {/* Load */}
                  <td className="py-3 px-3">
                    <span className={zone.loadPercentage > 85 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                      {zone.loadPercentage}%
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1">({zone.currentDemandMw} MW)</span>
                  </td>

                  {/* Temperature */}
                  <td className="py-3 px-3">
                    <span className={zone.temperature >= 40 ? 'text-rose-400 font-bold' : zone.temperature >= 35 ? 'text-amber-400' : 'text-slate-300'}>
                      {zone.temperature}°C
                    </span>
                  </td>

                  {/* Voltage Var */}
                  <td className="py-3 px-3">
                    <span className={zone.voltageVariation === 'HIGH' ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
                      {zone.voltageVariation}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-semibold ${
                      zone.substationStatus === 'ALERT' ? 'text-rose-400' : zone.substationStatus === 'WARNING' ? 'text-amber-400' : 'text-emerald-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        zone.substationStatus === 'ALERT' ? 'bg-rose-500 animate-pulse' : zone.substationStatus === 'WARNING' ? 'bg-amber-400' : 'bg-emerald-400'
                      }`} />
                      {zone.substationStatus}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAskAI(`Why is ${zone.shortCode} high risk?`);
                        }}
                        className="p-1 sm:px-2 sm:py-1 rounded bg-slate-800 hover:bg-cyan-950 text-cyan-300 border border-slate-700 hover:border-cyan-600 text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                        title={`Diagnose ${zone.shortCode} with Bob AI Assistant`}
                      >
                        <Bot className="w-3 h-3 text-cyan-400" />
                        <span className="hidden sm:inline">Diagnose</span>
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectZone(zone);
                        }}
                        className="p-1 rounded text-slate-400 hover:text-slate-200"
                        title="View details"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
