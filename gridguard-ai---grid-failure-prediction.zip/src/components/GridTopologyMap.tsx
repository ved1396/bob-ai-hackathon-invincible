import React from 'react';
import { GridZone } from '../types';
import { ShieldAlert, Zap, Thermometer, Gauge } from 'lucide-react';

interface GridTopologyMapProps {
  zones: GridZone[];
  selectedZone: GridZone | null;
  onSelectZone: (zone: GridZone) => void;
  onAskAIAboutZone: (zone: GridZone) => void;
}

export const GridTopologyMap: React.FC<GridTopologyMapProps> = ({
  zones,
  selectedZone,
  onSelectZone,
  onAskAIAboutZone,
}) => {
  // Mapping connections between zones to render transmission lines
  const connections: Array<{ from: GridZone; to: GridZone; key: string }> = [];
  const renderedPairs = new Set<string>();

  zones.forEach((zone) => {
    zone.connectedZoneIds.forEach((targetId) => {
      const target = zones.find((z) => z.id === targetId);
      if (target) {
        const pairKey = [zone.id, target.id].sort().join('--');
        if (!renderedPairs.has(pairKey)) {
          renderedPairs.add(pairKey);
          connections.push({ from: zone, to: target, key: pairKey });
        }
      }
    });
  });

  const getRiskColor = (risk: GridZone['riskLevel']) => {
    switch (risk) {
      case 'CRITICAL':
        return {
          stroke: '#f43f5e',
          fill: '#881337',
          glow: 'rgba(244, 63, 94, 0.4)',
          badge: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
        };
      case 'HIGH':
        return {
          stroke: '#fb7185',
          fill: '#4c0519',
          glow: 'rgba(251, 113, 133, 0.35)',
          badge: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
        };
      case 'MODERATE':
        return {
          stroke: '#fbbf24',
          fill: '#451a03',
          glow: 'rgba(251, 191, 36, 0.25)',
          badge: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
        };
      case 'LOW':
      default:
        return {
          stroke: '#34d399',
          fill: '#064e3b',
          glow: 'rgba(52, 211, 153, 0.2)',
          badge: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
        };
    }
  };

  return (
    <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-4 shadow-xl relative overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-2 border-b border-slate-800/80">
        <div>
          <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2 font-mono">
            <Zap className="w-4 h-4 text-cyan-400" />
            GRID INTERTIE TOPOLOGY MAP
          </h2>
          <p className="text-xs text-slate-400">
            Real-time power flow & ML failure probability by transmission zone
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-[11px] font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]" />
            <span className="text-slate-400">Low (&lt;25%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.5)]" />
            <span className="text-slate-400">Mod (25-50%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.6)]" />
            <span className="text-rose-300 font-bold">High (50-85%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse shadow-[0_0_10px_rgba(225,29,72,0.8)]" />
            <span className="text-rose-400 font-bold">Critical (&gt;85%)</span>
          </div>
        </div>
      </div>

      {/* SVG Map Canvas */}
      <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] bg-[#070b14] rounded-lg border border-slate-800/60 overflow-hidden">
        {/* Subtle background electrical grid matrix */}
        <div 
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#38bdf8 1px, transparent 1px)`,
            backgroundSize: '28px 28px'
          }}
        />

        <svg viewBox="0 0 800 560" className="w-full h-full">
          <defs>
            <filter id="glow-filter" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <linearGradient id="line-high-stress" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#fb923c" stopOpacity="0.6" />
            </linearGradient>
          </defs>

          {/* High Voltage Transmission Lines */}
          {connections.map((conn) => {
            const hasHighRisk = conn.from.riskLevel === 'HIGH' || conn.to.riskLevel === 'HIGH' || conn.from.riskLevel === 'CRITICAL' || conn.to.riskLevel === 'CRITICAL';
            const isSelectedLink = (selectedZone?.id === conn.from.id) || (selectedZone?.id === conn.to.id);

            return (
              <g key={conn.key}>
                {/* Outer shadow / glow line */}
                <line
                  x1={conn.from.coordinates.x}
                  y1={conn.from.coordinates.y}
                  x2={conn.to.coordinates.x}
                  y2={conn.to.coordinates.y}
                  stroke={hasHighRisk ? '#f43f5e' : '#0284c7'}
                  strokeWidth={isSelectedLink ? 4 : 2}
                  strokeOpacity={hasHighRisk ? 0.35 : 0.2}
                />

                {/* Animated transmission power pulse line */}
                <line
                  x1={conn.from.coordinates.x}
                  y1={conn.from.coordinates.y}
                  x2={conn.to.coordinates.x}
                  y2={conn.to.coordinates.y}
                  stroke={hasHighRisk ? '#fb7185' : '#38bdf8'}
                  strokeWidth={isSelectedLink ? 2.5 : 1.5}
                  strokeDasharray={hasHighRisk ? '6, 6' : '4, 8'}
                  className={hasHighRisk ? 'animate-pulse' : ''}
                />
              </g>
            );
          })}

          {/* Substation Nodes */}
          {zones.map((zone) => {
            const isSelected = selectedZone?.id === zone.id;
            const colors = getRiskColor(zone.riskLevel);
            const isZone4 = zone.shortCode === 'Zone 4';

            return (
              <g
                key={zone.id}
                transform={`translate(${zone.coordinates.x}, ${zone.coordinates.y})`}
                onClick={() => onSelectZone(zone)}
                className="cursor-pointer group"
              >
                {/* Active pulse aura for high risk nodes */}
                {(zone.riskLevel === 'HIGH' || zone.riskLevel === 'CRITICAL') && (
                  <circle
                    r={isSelected ? 36 : 28}
                    fill="none"
                    stroke={colors.stroke}
                    strokeWidth="1.5"
                    strokeOpacity="0.4"
                    className="animate-ping"
                    style={{ transformOrigin: '0 0' }}
                  />
                )}

                {/* Selection Ring */}
                {isSelected && (
                  <circle
                    r="34"
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    strokeDasharray="4 3"
                  />
                )}

                {/* Outer node shield */}
                <circle
                  r={isSelected ? 26 : 22}
                  fill={colors.fill}
                  stroke={colors.stroke}
                  strokeWidth={isSelected ? 3 : 2}
                  filter="url(#glow-filter)"
                  className="transition-all duration-300 group-hover:scale-110"
                />

                {/* Substation Center Ring */}
                <circle
                  r="8"
                  fill="#0b0f19"
                  stroke={colors.stroke}
                  strokeWidth="2"
                />

                {/* Failure Probability % inside or right below */}
                <text
                  y="4"
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize="10"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  {zone.failureProbability}%
                </text>

                {/* Node Label Plate */}
                <g transform="translate(0, 36)">
                  <rect
                    x="-55"
                    y="-10"
                    width="110"
                    height="20"
                    rx="4"
                    fill="#0f172a"
                    stroke={isSelected ? '#38bdf8' : '#334155'}
                    strokeWidth={isSelected ? 1.5 : 1}
                    className="group-hover:stroke-slate-400"
                  />
                  <text
                    textAnchor="middle"
                    y="4"
                    fill={isSelected ? '#38bdf8' : '#e2e8f0'}
                    fontSize="11"
                    fontWeight="600"
                    fontFamily="monospace"
                  >
                    {zone.shortCode}
                  </text>
                </g>

                {/* Status Indicator Tag for Zone 4 or High Risk */}
                {isZone4 && (
                  <g transform="translate(0, -32)">
                    <rect
                      x="-38"
                      y="-8"
                      width="76"
                      height="16"
                      rx="3"
                      fill="#991b1b"
                      stroke="#f87171"
                      strokeWidth="1"
                    />
                    <text
                      textAnchor="middle"
                      y="4"
                      fill="#ffffff"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      HIGH RISK: 78%
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>

        {/* Selected Zone Quick Overlay (Floating on Map) */}
        {selectedZone && (
          <div className="absolute top-3 right-3 bg-slate-950/95 border border-cyan-500/40 rounded-lg p-3 shadow-2xl backdrop-blur-md max-w-xs text-xs font-mono">
            <div className="flex items-center justify-between gap-2 pb-1.5 mb-1.5 border-b border-slate-800">
              <span className="font-bold text-white text-sm">{selectedZone.name}</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getRiskColor(selectedZone.riskLevel).badge}`}>
                {selectedZone.riskLevel}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-slate-300 my-2">
              <div className="flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>Risk:</span>
                <strong className={selectedZone.failureProbability > 50 ? 'text-rose-400' : 'text-slate-100'}>
                  {selectedZone.failureProbability}%
                </strong>
              </div>
              <div className="flex items-center gap-1.5">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                <span>Load:</span>
                <strong className={selectedZone.loadPercentage > 85 ? 'text-rose-400' : 'text-slate-100'}>
                  {selectedZone.loadPercentage}%
                </strong>
              </div>
              <div className="flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                <span>Temp:</span>
                <strong className={selectedZone.temperature > 38 ? 'text-amber-400' : 'text-slate-100'}>
                  {selectedZone.temperature}°C
                </strong>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-indigo-400" />
                <span>Volt Var:</span>
                <strong className={selectedZone.voltageVariation === 'HIGH' ? 'text-rose-400' : 'text-slate-100'}>
                  {selectedZone.voltageVariation}
                </strong>
              </div>
            </div>

            <button
              onClick={() => onAskAIAboutZone(selectedZone)}
              className="w-full mt-1.5 py-1.5 px-2 bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-600/50 rounded flex items-center justify-center gap-1.5 font-semibold text-[11px] transition-colors cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              Ask GridGuard AI: "Why is {selectedZone.shortCode} at risk?"
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
