import React, { useState } from 'react';
import { GridZone, VoltageVariation } from '../types';
import { 
  ShieldAlert, 
  Thermometer, 
  Gauge, 
  Zap, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Bot, 
  Wrench,
  RotateCcw
} from 'lucide-react';

interface ZoneDetailCardProps {
  zone: GridZone;
  onUpdateTelemetry: (zoneId: string, updates: Partial<GridZone>) => Promise<void>;
  onAskAI: (query: string) => void;
  isUpdating: boolean;
}

export const ZoneDetailCard: React.FC<ZoneDetailCardProps> = ({
  zone,
  onUpdateTelemetry,
  onAskAI,
  isUpdating,
}) => {
  const [showSimulator, setShowSimulator] = useState(false);
  const [simLoad, setSimLoad] = useState(zone.loadPercentage);
  const [simTemp, setSimTemp] = useState(zone.temperature);
  const [simVoltage, setSimVoltage] = useState<VoltageVariation>(zone.voltageVariation);

  // Sync state when selected zone changes
  React.useEffect(() => {
    setSimLoad(zone.loadPercentage);
    setSimTemp(zone.temperature);
    setSimVoltage(zone.voltageVariation);
  }, [zone.id, zone.loadPercentage, zone.temperature, zone.voltageVariation]);

  const handleApplySimulation = async () => {
    await onUpdateTelemetry(zone.id, {
      loadPercentage: simLoad,
      temperature: simTemp,
      voltageVariation: simVoltage,
    });
  };

  const handleApplyPreventiveAction = async () => {
    // Mitigate: reduce load by 15%, cooling lowers temp by 6°C, normalize voltage
    await onUpdateTelemetry(zone.id, {
      loadPercentage: Math.max(50, zone.loadPercentage - 16),
      temperature: Math.max(25, zone.temperature - 7),
      voltageVariation: 'NORMAL',
    });
  };

  const isHighRisk = zone.failureProbability >= 50;

  return (
    <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-5 shadow-xl font-mono text-xs flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-400 font-bold border border-slate-700">
                {zone.shortCode}
              </span>
              <h3 className="text-base font-bold text-white tracking-wide">
                {zone.name}
              </h3>
            </div>
            <p className="text-slate-400 mt-0.5 text-[11px]">
              {zone.substationType} • Status: <span className={zone.substationStatus === 'ONLINE' ? 'text-emerald-400' : 'text-rose-400 font-bold'}>{zone.substationStatus}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`px-2.5 py-1 rounded font-bold uppercase tracking-wider text-[11px] border ${
                zone.riskLevel === 'CRITICAL'
                  ? 'bg-rose-950/80 text-rose-300 border-rose-600'
                  : zone.riskLevel === 'HIGH'
                  ? 'bg-rose-900/40 text-rose-300 border-rose-700/60'
                  : zone.riskLevel === 'MODERATE'
                  ? 'bg-amber-900/30 text-amber-300 border-amber-600/40'
                  : 'bg-emerald-900/30 text-emerald-300 border-emerald-600/40'
              }`}
            >
              {zone.riskLevel} RISK
            </span>

            <button
              onClick={() => onAskAI(`Why is ${zone.shortCode} high risk?`)}
              className="px-2.5 py-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-600/50 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Query AI diagnostic on this zone"
            >
              <Bot className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ask AI</span>
            </button>
          </div>
        </div>

        {/* Failure Probability Hero Gauge */}
        <div className="my-4 p-4 rounded-lg bg-slate-950/80 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 flex-shrink-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-800"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={isHighRisk ? 'text-rose-500' : zone.failureProbability > 25 ? 'text-amber-400' : 'text-emerald-400'}
                  strokeDasharray={`${zone.failureProbability}, 100`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-sm font-bold text-white">
                {zone.failureProbability}%
              </span>
            </div>

            <div>
              <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                ML Failure Probability
              </div>
              <div className="text-lg font-bold text-white flex items-center gap-2">
                <span>{zone.failureProbability}% Calculated Risk</span>
                {zone.failureProbability >= 70 && (
                  <ShieldAlert className="w-4 h-4 text-rose-500 animate-pulse" />
                )}
              </div>
              <div className="text-slate-400 text-[11px]">
                Ground truth from GridGuard XGBoost predictive engine
              </div>
            </div>
          </div>

          {/* Action button if stressed */}
          {zone.failureProbability >= 40 && (
            <button
              onClick={handleApplyPreventiveAction}
              disabled={isUpdating}
              className="px-3 py-2 rounded-md bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 border border-emerald-600/50 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>Apply Recommended Mitigations</span>
            </button>
          )}
        </div>

        {/* Telemetry Sensor Readings Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
          {/* Load */}
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                Feeder Load
              </span>
            </div>
            <div className="text-base font-bold text-white">
              {zone.loadPercentage}%
            </div>
            <div className="text-[10px] text-slate-400">
              {zone.currentDemandMw} / {zone.capacityMw} MW
            </div>
          </div>

          {/* Core Temperature */}
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                Core Temp
              </span>
            </div>
            <div className={`text-base font-bold ${zone.temperature >= 40 ? 'text-rose-400' : zone.temperature >= 35 ? 'text-amber-400' : 'text-slate-200'}`}>
              {zone.temperature}°C
            </div>
            <div className="text-[10px] text-slate-400">
              {zone.temperature >= 40 ? 'Critical Thermal Limit' : 'Normal operating band'}
            </div>
          </div>

          {/* Voltage Variation */}
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-indigo-400" />
                Voltage Var
              </span>
            </div>
            <div className={`text-base font-bold ${zone.voltageVariation === 'HIGH' ? 'text-rose-400' : zone.voltageVariation === 'ELEVATED' ? 'text-amber-400' : 'text-slate-200'}`}>
              {zone.voltageVariation}
            </div>
            <div className="text-[10px] text-slate-400">
              {zone.voltageKv} kV / {zone.nominalVoltageKv} kV
            </div>
          </div>

          {/* Frequency & Vibration */}
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                Freq / Vib
              </span>
            </div>
            <div className="text-base font-bold text-white">
              {zone.frequencyHz} Hz
            </div>
            <div className="text-[10px] text-slate-400">
              Vibration: {zone.transformerVibrationMmS} mm/s
            </div>
          </div>
        </div>

        {/* Primary ML Risk Drivers */}
        <div className="mb-3">
          <div className="text-[11px] font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            ML FEATURE ATTRIBUTION & PRIMARY RISK DRIVERS:
          </div>
          <ul className="space-y-1 pl-1">
            {zone.primaryRiskDrivers.map((driver, idx) => (
              <li key={idx} className="text-slate-400 flex items-start gap-2">
                <span className="text-rose-400 font-bold">•</span>
                <span>{driver}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Recommended Preventive Actions */}
        <div className="mb-4">
          <div className="text-[11px] font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
            RECOMMENDED PREVENTIVE ACTIONS:
          </div>
          <ul className="space-y-1 pl-1">
            {zone.recommendedActions.map((action, idx) => (
              <li key={idx} className="text-slate-300 flex items-start gap-2">
                <span className="text-cyan-400 font-bold">→</span>
                <span>{action}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* What-If Telemetry Simulator Drawer */}
      <div className="pt-3 border-t border-slate-800">
        <button
          onClick={() => setShowSimulator(!showSimulator)}
          className="w-full py-1.5 px-3 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 flex items-center justify-between transition-colors cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            <span>Interactive Telemetry & What-If Simulator</span>
          </span>
          <span className="text-[10px] text-slate-400">
            {showSimulator ? 'Hide Controls ▲' : 'Tune Telemetry ▼'}
          </span>
        </button>

        {showSimulator && (
          <div className="mt-3 p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-3">
            <div className="text-[10px] text-slate-400">
              Adjust sensors to observe real-time recalculation of the ML failure model, then query Bob AI Assistant.
            </div>

            {/* Load Slider */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Feeder Load:</span>
                <span className="font-bold text-cyan-400">{simLoad}%</span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                value={simLoad}
                onChange={(e) => setSimLoad(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Temperature Slider */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Core Temperature:</span>
                <span className="font-bold text-amber-400">{simTemp}°C</span>
              </div>
              <input
                type="range"
                min="20"
                max="50"
                value={simTemp}
                onChange={(e) => setSimTemp(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Voltage Variation Select */}
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Voltage Fluctuation:</span>
                <span className="font-bold text-indigo-400">{simVoltage}</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {(['LOW', 'NORMAL', 'ELEVATED', 'HIGH'] as VoltageVariation[]).map((v) => (
                  <button
                    key={v}
                    onClick={() => setSimVoltage(v)}
                    className={`py-1 rounded text-[10px] font-semibold border transition-colors cursor-pointer ${
                      simVoltage === v
                        ? 'bg-cyan-950 text-cyan-300 border-cyan-500'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleApplySimulation}
                disabled={isUpdating}
                className="flex-1 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors cursor-pointer"
              >
                {isUpdating ? 'Recomputing ML Model...' : 'Apply & Recalculate ML Risk'}
              </button>
              <button
                onClick={() => {
                  setSimLoad(zone.loadPercentage);
                  setSimTemp(zone.temperature);
                  setSimVoltage(zone.voltageVariation);
                }}
                className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title="Reset simulation inputs"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
