import React, { useState, useEffect } from 'react';
import { GridSystemState, GridZone } from './types';
import { GridHeader } from './components/GridHeader';
import { GridTopologyMap } from './components/GridTopologyMap';
import { ZoneDetailCard } from './components/ZoneDetailCard';
import { ZonesTable } from './components/ZonesTable';
import { GridGuardChatbot } from './components/GridGuardChatbot';
import { ShieldAlert, Bot, Sparkles, RefreshCw, AlertTriangle, ArrowRight } from 'lucide-react';

export default function App() {
  const [gridState, setGridState] = useState<GridSystemState | null>(null);
  const [selectedZone, setSelectedZone] = useState<GridZone | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [queuedChatQuery, setQueuedChatQuery] = useState<string | null>(null);

  // Fetch initial grid status from server
  const fetchGridStatus = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/grid/status');
      if (!res.ok) throw new Error('Failed to load grid telemetry');
      const data: GridSystemState = await res.json();
      setGridState(data);

      // Default selection: Zone 4 (The benchmark high-risk zone) or first zone
      if (!selectedZone) {
        const zone4 = data.zones.find((z) => z.shortCode === 'Zone 4') || data.zones[0];
        setSelectedZone(zone4);
      } else {
        // Keep updated telemetry for currently selected zone
        const updated = data.zones.find((z) => z.id === selectedZone.id);
        if (updated) setSelectedZone(updated);
      }
    } catch (err) {
      console.error('Error fetching grid status:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchGridStatus();
  }, []);

  // Update telemetry and recompute ML failure risk
  const handleUpdateTelemetry = async (zoneId: string, updates: Partial<GridZone>) => {
    try {
      setIsUpdating(true);
      const res = await fetch('/api/grid/telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: zoneId, ...updates }),
      });

      if (!res.ok) throw new Error('Failed to update telemetry');
      const data = await res.json();
      setSelectedZone(data.zone);
      setGridState(data.gridStatus);
    } catch (err) {
      console.error('Error updating telemetry:', err);
    } finally {
      setIsUpdating(false);
    }
  };

  // Reset to default baseline ground truth
  const handleReset = async () => {
    try {
      setIsUpdating(true);
      const res = await fetch('/api/grid/reset', { method: 'POST' });
      if (!res.ok) throw new Error('Failed to reset grid');
      const data: GridSystemState = await res.json();
      setGridState(data);
      const zone4 = data.zones.find((z) => z.shortCode === 'Zone 4') || data.zones[0];
      setSelectedZone(zone4);
    } catch (err) {
      console.error('Error resetting grid:', err);
    } finally {
      setIsUpdating(false);
    }
  };

  // Simulate stress scenarios
  const handleSimulate = async (scenario: 'heatwave' | 'mitigated' | 'severe_contingency') => {
    try {
      setIsUpdating(true);
      const res = await fetch('/api/grid/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario }),
      });
      if (!res.ok) throw new Error('Simulation failed');
      const data = await res.json();
      setGridState(data.gridStatus);
      if (selectedZone) {
        const updated = data.gridStatus.zones.find((z: GridZone) => z.id === selectedZone.id);
        if (updated) setSelectedZone(updated);
      }
    } catch (err) {
      console.error('Error running simulation:', err);
    } finally {
      setIsUpdating(false);
    }
  };

  // Open chatbot with predefined query
  const handleAskAI = (query: string) => {
    setQueuedChatQuery(query);
    setIsChatOpen(true);
  };

  // Select zone by shortCode (e.g. from chatbot message click)
  const handleSelectZoneByCode = (code: string) => {
    if (!gridState) return;
    const normalized = code.toLowerCase().replace(/\s+/g, '');
    const found = gridState.zones.find(
      (z) => z.shortCode.toLowerCase().replace(/\s+/g, '') === normalized || z.id === code
    );
    if (found) {
      setSelectedZone(found);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-mono selection:bg-cyan-500/30">
      {/* Header */}
      <GridHeader
        gridState={gridState}
        isLoading={isLoading}
        onReset={handleReset}
        onSimulate={handleSimulate}
        onOpenChat={() => setIsChatOpen(true)}
        isChatOpen={isChatOpen}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        
        {/* Active Alert Banner for Zone 4 / High Risk zones */}
        {gridState && gridState.highRiskZonesCount > 0 && (
          <div className="p-3.5 sm:p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-start sm:items-center gap-3">
              <div className="p-2 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 flex-shrink-0">
                <ShieldAlert className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span>CRITICAL TELEMETRY ALERT: Zone 4 at 78% Failure Risk</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-900 text-rose-200 border border-rose-700">
                    HIGH RISK
                  </span>
                </div>
                <p className="text-rose-300/80 text-[11px] mt-0.5">
                  High load (91%), abnormal voltage variation (HIGH), and elevated core temperature (42°C) detected on Highland Substation.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center flex-shrink-0">
              <button
                onClick={() => handleAskAI('Why is Zone 4 high risk?')}
                className="px-3 py-1.5 rounded-md bg-rose-900 hover:bg-rose-800 text-white font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm text-xs"
              >
                <Bot className="w-3.5 h-3.5 text-cyan-300" />
                <span>Ask AI: Why is Zone 4 high risk?</span>
              </button>
            </div>
          </div>
        )}

        {/* Suggested AI Questions Quick Access Bar */}
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold flex-shrink-0">
            <Sparkles className="w-4 h-4" />
            <span>Bob AI Assistant Quick Diagnostics:</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => handleAskAI('Which zone has the highest failure risk?')}
              className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-cyan-950 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-700/60 text-[11px] transition-colors cursor-pointer"
            >
              Which zone is at highest risk?
            </button>
            <button
              onClick={() => handleAskAI('Why is Zone 4 high risk?')}
              className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-cyan-950 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-700/60 text-[11px] transition-colors cursor-pointer"
            >
              Why is Zone 4 high risk?
            </button>
            <button
              onClick={() => handleAskAI('Show critical zones')}
              className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-cyan-950 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-700/60 text-[11px] transition-colors cursor-pointer"
            >
              Show critical zones
            </button>
            <button
              onClick={() => handleAskAI('What preventive actions are recommended?')}
              className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-cyan-950 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-700/60 text-[11px] transition-colors cursor-pointer"
            >
              What preventive action should be taken?
            </button>
            <button
              onClick={() => handleAskAI('Compare Zone 2 and Zone 4.')}
              className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-cyan-950 text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-700/60 text-[11px] transition-colors cursor-pointer"
            >
              Compare Zone 2 and Zone 4
            </button>
          </div>
        </div>

        {/* Dashboard Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Topology Map + Regional Table (7 cols on lg) */}
          <div className="lg:col-span-7 space-y-6">
            {gridState && (
              <GridTopologyMap
                zones={gridState.zones}
                selectedZone={selectedZone}
                onSelectZone={(zone) => setSelectedZone(zone)}
                onAskAIAboutZone={(zone) => handleAskAI(`Why is ${zone.shortCode} high risk?`)}
              />
            )}

            {gridState && (
              <ZonesTable
                zones={gridState.zones}
                selectedZoneId={selectedZone?.id}
                onSelectZone={(zone) => setSelectedZone(zone)}
                onAskAI={handleAskAI}
              />
            )}
          </div>

          {/* Right Column: Selected Zone Detail & What-If Telemetry Simulator (5 cols on lg) */}
          <div className="lg:col-span-5 space-y-6">
            {selectedZone ? (
              <ZoneDetailCard
                zone={selectedZone}
                onUpdateTelemetry={handleUpdateTelemetry}
                onAskAI={handleAskAI}
                isUpdating={isUpdating}
              />
            ) : (
              <div className="p-8 rounded-xl bg-slate-900 border border-slate-800 text-center text-slate-400">
                Select a zone to inspect telemetry and machine learning failure predictions.
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Floating GridGuard AI Chatbot Component */}
      <GridGuardChatbot
        isOpen={isChatOpen}
        onToggleOpen={() => setIsChatOpen(!isChatOpen)}
        onSelectZoneByCode={handleSelectZoneByCode}
        externalQuery={queuedChatQuery}
        onClearExternalQuery={() => setQueuedChatQuery(null)}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-[#090d18] py-4 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            GridGuard Power Grid Failure Prediction System • Model {gridState?.mlModelVersion || 'v4.2.8'}
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>Server-side Google Gemini 3.8 Flash Engine</span>
            <span>•</span>
            <span className="text-cyan-400">SCADA Synchronized</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
